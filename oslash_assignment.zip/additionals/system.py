# system details and information
filePathError = "File path not entered"
readOnly = "r"
maxArgs = 2
filePath = 1

# main function
main = "__main__"
