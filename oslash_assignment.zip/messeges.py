filePathError = "File path not entered"
addItem = "ADD_ITEM"
error = "ERROR_QUANTITY_EXCEEDED\n"
success = "ITEM_ADDED\n"
discount = "TOTAL_DISCOUNT "
finalAmount = "TOTAL_AMOUNT_TO_PAY "
newLine = "\n"


